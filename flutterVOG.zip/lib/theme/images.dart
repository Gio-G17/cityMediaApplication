//-----BACKGROUND-----
String backgroundImage = "assets/background_image/background_image_2.jpg";

//-----LOGO-----
String logoImage = "assets/logo/white_image_2.jpg";
