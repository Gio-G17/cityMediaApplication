import 'package:flutter/material.dart';

class AboutSizedBox extends StatelessWidget {
  const AboutSizedBox({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return const SizedBox(height: 10);
  }
}
