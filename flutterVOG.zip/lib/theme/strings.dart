//-----DRAWER PAGE-----
String home = "Home";
String rateUs = 'Rate us';
String share = 'Share to friends';
String privacyPolicy = 'Privacy policy';
String about = 'About';
String ok = "OK";
