import 'package:flutter/material.dart';

class HomeShadeContainer extends StatelessWidget {
  const HomeShadeContainer({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color.fromARGB(36, 8, 2, 2),
    );
  }
}
